module.exports = require('./lib/Granim.js');
